package com.sistemaing2.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfucionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfucionApplication.class, args);
	}

}
